create database MenorRota;
use MenorRota;
CREATE TABLE Entregas (
    delivery_id INT AUTO_INCREMENT PRIMARY KEY,
    delivery_date DATE,
    tracking_number VARCHAR(20),
    delivery_address VARCHAR(100),
    delivery_status ENUM('Pending','In Progress','Completed','Cancelled'),
    sender_id INT, -- Chave estrangeira para remetentes
    recipient_id INT -- Chave estrangeira para destinatários
);

select*from Entregas;

INSERT INTO Entregas (delivery_date, tracking_number, delivery_address, delivery_status, sender_id, recipient_id)
VALUES ('2022-06-20', '167234', '11111-111', 'Completed','27', '78');

-- Cria um gatilho que exclui entregas concluídas
DELIMITER //
CREATE TRIGGER DeleteCompletedDelivery
AFTER UPDATE ON Entregas FOR EACH ROW
BEGIN
    IF NEW.delivery_status = 'Completed' THEN
        DELETE FROM Entregas WHERE delivery_id = NEW.delivery_id;
    END IF;
END;
//
DELIMITER ;






